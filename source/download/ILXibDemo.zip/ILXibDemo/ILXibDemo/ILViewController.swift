//
//  ILViewController.swift
//  ILXibDemo
//
//  Created by MAC on 16/7/26.
//  Copyright © 2016年 Team. All rights reserved.
//

import UIKit

class ILViewController: UIViewController {

     @IBOutlet weak var label: UILabel!

}


class ILFlagController: UIViewController {
    
    @IBOutlet weak var label: UILabel!
    
}
